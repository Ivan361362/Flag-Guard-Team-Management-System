<template>
  <view class="page-container">
    <u-navbar title="马靴管理" bgColor="#f8f9fa"></u-navbar>
    
    <view class="content-box">
      <u-form :model="bootForm">
        <u-form-item label="马靴尺码">
          <u-input-number v-model="bootForm.size" :min="35" :max="50" />
        </u-form-item>
        
        <u-form-item label="损坏部位">
          <u-checkbox-group v-model="bootForm.damageParts">
            <u-checkbox name="鞋底">鞋底</u-checkbox>
            <u-checkbox name="鞋面">鞋面</u-checkbox>
            <u-checkbox name="鞋跟">鞋跟</u-checkbox>
          </u-checkbox-group>
        </u-form-item>

        <u-button @click="addBoot">添加记录</u-button>
      </u-form>

      <u-list :data="bootList" class="boot-list">
        <template v-slot:default="{ item, index }">
          <u-card :title="`尺码：${item.size}`">
            <text v-if="item.damageParts.length" class="damage-text">
              损坏部位：{{ item.damageParts.join('、') }}
            </text>
            <text v-else class="normal-text">状态正常</text>
          </u-card>
        </template>
      </u-list>
    </view>
  </view>
</template>

<script setup>
import { ref } from 'vue';

const bootForm = ref({
  size: 38,
  damageParts: []
});

const bootList = ref([]);

const addBoot = () => {
  bootList.value.push({...bootForm.value});
  bootForm.value = { size: 38, damageParts: [] };
};
</script>