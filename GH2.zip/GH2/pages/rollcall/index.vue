<template>
  <view class="page-container">
    <u-navbar title="训练点名" bgColor="#f8f9fa"></u-navbar>
    
    <view class="rollcall-box">
      <u-checkbox-group v-model="attendance">
        <view v-for="member in memberList" :key="member.id" class="member-item">
          <u-checkbox :name="member.id">{{ member.name }}</u-checkbox>
          <u-tag :text="member.status" 
                 :type="member.status === '请假' ? 'warning' : 'info'" />
        </view>
      </u-checkbox-group>
      
      <u-button @click="submitAttendance">提交考勤</u-button>
    </view>
  </view>
</template>