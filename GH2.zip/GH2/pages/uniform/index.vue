<template>
  <view class="page-container">
    <u-navbar title="军装管理" leftIcon="" bgColor="#f8f9fa"></u-navbar>
    
    <view class="content-box">
      <u-form :model="formData" ref="uniformForm">
        <u-form-item label="军种类型" required>
          <u-radio-group v-model="formData.type">
            <u-radio name="海军" label="海军"></u-radio>
            <u-radio name="陆军" label="陆军"></u-radio>
            <u-radio name="空军" label="空军"></u-radio>
          </u-radio-group>
        </u-form-item>

        <u-form-item label="尺码信息">
          <u-input v-model="formData.size.hat" placeholder="帽子尺码" border />
          <u-input v-model="formData.size.coat" placeholder="上衣尺码" border />
          <u-input v-model="formData.size.pants" placeholder="裤子尺码" border />
        </u-form-item>

        <u-form-item label="损坏情况">
          <u-textarea v-model="formData.damage" placeholder="填写损坏部位及程度" />
        </u-form-item>

        <u-button type="primary" @click="saveData">保存记录</u-button>
      </u-form>

      <u-table :data="uniformList" class="data-table">
        <u-tr>
          <u-th>军种</u-th>
          <u-th>上衣尺码</u-th>
          <u-th>状态</u-th>
        </u-tr>
        <u-tr v-for="(item,index) in uniformList" :key="index">
          <u-td>{{ item.type }}</u-td>
          <u-td>{{ item.size.coat }}</u-td>
          <u-td>
            <u-tag :text="item.damage ? '需维修' : '正常'" 
                   :type="item.damage ? 'error' : 'success'" />
          </u-td>
        </u-tr>
      </u-table>
    </view>
  </view>
</template>

<script setup>
import { ref, onMounted } from 'vue';

const formData = ref({
  type: '',
  size: { hat: '', coat: '', pants: '' },
  damage: ''
});

const uniformList = ref([]);

const loadData = async () => {
  try {
    const res = await uni.getStorage({ key: 'uniformData' });
    uniformList.value = res.data || [];
  } catch (e) {
    console.error('数据加载失败:', e);
  }
};

const saveData = async () => {
  if (!formData.value.type) {
    return uni.showToast({ title: '请选择军种类型', icon: 'none' });
  }
  
  uniformList.value.push({...formData.value});
  await uni.setStorage({ key: 'uniformData', data: uniformList.value });
  formData.value = { type: '', size: { hat: '', coat: '', pants: '' }, damage: '' };
  uni.showToast({ title: '保存成功' });
};

onMounted(loadData);
</script>

<style lang="scss" scoped>
.content-box {
  padding: 20rpx;
  
  .data-table {
    margin-top: 40rpx;
    background: #fff;
    border-radius: 12rpx;
    box-shadow: 0 4rpx 12rpx rgba(0,0,0,0.08);
  }
}
</style>