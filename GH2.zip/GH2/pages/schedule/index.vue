<template>
  <view class="page-container">
    <u-navbar title="日程管理" bgColor="#f8f9fa"></u-navbar>
    
    <view class="calendar-wrapper">
      <uni-calendar
        :events="calendarEvents"
        @monthChange="handleMonthChange"
        @dateClick="handleDateClick"
      />
      
      <u-popup v-model="showEventEdit" mode="center">
        <event-editor @save="saveEvent" />
      </u-popup>
    </view>
  </view>
</template>

<script setup>
import { ref } from 'vue';

const calendarEvents = ref([
  { date: '2024-03-10', info: '季度考核', color: '#c7000a' }
]);

const showEventEdit = ref(false);

const handleDateClick = (e) => {
  showEventEdit.value = true;
};

const saveEvent = (newEvent) => {
  calendarEvents.value.push(newEvent);
  showEventEdit.value = false;
};
</script>