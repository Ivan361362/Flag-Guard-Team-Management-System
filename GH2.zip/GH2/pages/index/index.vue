<template>
  <view class="index-container">
    <!-- 顶部导航 -->
    <u-navbar
      title="国旗护卫队管理系统"
      :border="true"
      bgColor="linear-gradient(to right, #c7000a, #003478)"
      titleColor="#fff"
    ></u-navbar>

    <!-- 功能入口 -->
    <view class="dashboard">
      <!-- 数据概览 -->
      <view class="stats-card">
        <u-row>
          <u-col span="4">
            <view class="stat-item">
              <text class="num">156</text>
              <text class="label">在册军装</text>
            </view>
          </u-col>
          <u-col span="4">
            <view class="stat-item">
              <text class="num">32</text>
              <text class="label">本周排班</text>
            </view>
          </u-col>
          <u-col span="4">
            <view class="stat-item">
              <text class="num">98%</text>
              <text class="label">出勤率</text>
            </view>
          </u-col>
        </u-row>
      </view>

      <!-- 功能入口网格 -->
      <u-grid :col="3" :border="false" class="function-grid">
        <u-grid-item 
          v-for="(item, index) in menuItems" 
          :key="index"
          @click="navigateTo(item.path)"
        >
          <view class="menu-card" :style="{backgroundColor: item.color}">
            <image 
              :src="item.icon" 
              mode="aspectFit" 
              class="menu-icon"
            />
            <text class="menu-title">{{ item.title }}</text>
          </view>
        </u-grid-item>
      </u-grid>

      <!-- 最近事件 -->
      <view class="recent-events">
        <view class="section-title">
          <u-icon name="calendar" size="24"></u-icon>
          <text>近期安排</text>
        </view>
        <u-timeline>
          <u-timeline-item 
            v-for="(event, index) in recentEvents"
            :key="index"
            :timestamp="event.date"
            :title="event.title"
            icon="bell"
            nodeSize="20"
          />
        </u-timeline>
      </view>
    </view>

    <!-- 底部版权 -->
    <view class="footer">
      <text>© 2024 国旗护卫队信息中心</text>
    </view>
  </view>
</template>

<script setup>
import { ref } from 'vue';

const menuItems = ref([
  { 
    title: '军装管理', 
    icon: '/static/icons/uniform.png',
    path: '/pages/uniform/index',
    color: '#c7000a' 
  },
  { 
    title: '马靴管理', 
    icon: '/static/icons/boots.png',
    path: '/pages/boots/index',
    color: '#003478' 
  },
  { 
    title: '日程管理', 
    icon: '/static/icons/calendar.png',
    path: '/pages/schedule/index',
    color: '#ffd700' 
  },
  { 
    title: '升旗排班', 
    icon: '/static/icons/flag.png',
    path: '/pages/flag-duty/index',
    color: '#c7000a' 
  },
  { 
    title: '训练点名', 
    icon: '/static/icons/rollcall.png',
    path: '/pages/rollcall/index',
    color: '#003478' 
  },
  { 
    title: '军装检索', 
    icon: '/static/icons/search.png',
    path: '/pages/search/index',
    color: '#ffd700' 
  }
]);

const recentEvents = ref([
  { date: '2024-03-04', title: '周一升旗仪式' },
  { date: '2024-03-05', title: '春季服装检查' },
  { date: '2024-03-07', title: '队列训练考核' }
]);

// const navigateTo = (path) => {
//   uni.navigateTo({
//     url: path
//   });
// };
const navigateTo = (path) => {
  // 检查路径有效性
  if (!path.startsWith('/')) {
    console.error('路径必须以/开头');
    return;
  }
  
  uni.navigateTo({
    url: path,
    fail: (err) => {
      console.error('跳转失败:', err);
      uni.showToast({
        title: '功能正在开发中',
        icon: 'none'
      });
    }
  });
};
</script>

<style lang="scss" scoped>
.index-container {
  min-height: 100vh;
  background: #f8f9fa;

  .dashboard {
    padding: 20rpx;

    .stats-card {
      background: white;
      border-radius: 16rpx;
      padding: 30rpx;
      margin: 20rpx;
      box-shadow: 0 4rpx 12rpx rgba(0,0,0,0.08);

      .stat-item {
        display: flex;
        flex-direction: column;
        align-items: center;

        .num {
          font-size: 36rpx;
          font-weight: bold;
          color: var(--primary-color);
        }

        .label {
          font-size: 24rpx;
          color: #666;
          margin-top: 10rpx;
        }
      }
    }

    .function-grid {
      margin: 20rpx 0;

      .menu-card {
        width: 90%;
        height: 240rpx;
        border-radius: 24rpx;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        transition: transform 0.3s ease;
        box-shadow: 0 6rpx 18rpx rgba(0,0,0,0.1);

        &:active {
          transform: scale(0.95);
        }

        .menu-icon {
          width: 80rpx;
          height: 80rpx;
          margin-bottom: 20rpx;
        }

        .menu-title {
          color: white;
          font-size: 28rpx;
          font-weight: 500;
          text-shadow: 0 2rpx 4rpx rgba(0,0,0,0.2);
        }
      }
    }

    .recent-events {
      background: white;
      border-radius: 16rpx;
      padding: 30rpx;
      margin: 20rpx;
      box-shadow: 0 4rpx 12rpx rgba(0,0,0,0.08);

      .section-title {
        display: flex;
        align-items: center;
        margin-bottom: 30rpx;
        
        text {
          font-size: 32rpx;
          font-weight: bold;
          margin-left: 15rpx;
          color: var(--primary-color);
        }
      }
    }
  }

  .footer {
    text-align: center;
    padding: 40rpx 0;
    color: #999;
    font-size: 24rpx;
  }
}
</style>