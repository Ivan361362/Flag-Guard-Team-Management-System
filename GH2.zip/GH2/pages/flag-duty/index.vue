<template>
  <view class="page-container">
    <u-navbar title="升旗排班" bgColor="#f8f9fa"></u-navbar>
    
    <view class="duty-form">
      <u-form :model="dutyData">
        <u-form-item label="升旗日期">
          <uni-datetime-picker v-model="dutyData.date" />
        </u-form-item>
        
        <u-form-item label="主旗手">
          <u-input v-model="dutyData.main" placeholder="输入姓名" />
        </u-form-item>
        
        <u-form-item label="护旗手名单">
          <u-tag-input v-model="dutyData.support" placeholder="添加护旗人员" />
        </u-form-item>

        <u-button @click="saveSchedule">保存排班</u-button>
      </u-form>

      <u-timeline class="schedule-list">
        <u-timeline-item v-for="item in scheduleList" 
                         :title="item.date" 
                         :subTitle="`主旗手：${item.main}`" />
      </u-timeline>
    </view>
  </view>
</template>