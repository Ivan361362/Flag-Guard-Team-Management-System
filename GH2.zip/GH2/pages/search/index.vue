<template>
  <view class="page-container">
    <u-navbar title="军装检索" bgColor="#f8f9fa"></u-navbar>
    
    <view class="search-box">
      <u-filter @confirm="doSearch">
        <u-filter-item label="军种" :options="militaryTypes" v-model="searchForm.type" />
        <u-filter-item label="尺码" :options="sizeOptions" v-model="searchForm.size" />
      </u-filter>

      <u-list :data="searchResults">
        <template v-slot:default="{ item }">
          <uniform-card :data="item" />
        </template>
      </u-list>
    </view>
  </view>
</template>